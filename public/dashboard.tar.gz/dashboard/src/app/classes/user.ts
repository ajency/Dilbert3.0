export class User {
      id: number;
      name: string;
      email: string;
      avatar: string;
      token: string;
}
